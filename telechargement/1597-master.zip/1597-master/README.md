# 1597
A fibonacci version of: the popular 2048 game, originally created by [Gabriele Cirulli](https://github.com/gabrielecirulli)

[Play it here!](http://jmhummel.github.io/1597/)
