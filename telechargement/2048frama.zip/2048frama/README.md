Made just for fun. [Play it here!](http://amschrader.github.io/2048/)
